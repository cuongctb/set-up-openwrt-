while true; do
 curl -s http://186.186.0.1/logout
 curl -s "http://186.186.0.1/login?username=awing120-120&password=Awing120-120@2023"
 sleep 7199
done
